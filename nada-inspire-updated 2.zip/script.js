
const quotes = [
    "ابتسم، فإن في الابتسامة حياة.",
    "كل شيء سيكون على ما يرام.",
    "ثِق بخطواتك، ولو كانت بطيئة.",
    "التغيير يبدأ من داخلك.",
    "كن النور في عتمة يوم أحدهم."
];

let quoteBox = document.getElementById("quote");
setInterval(() => {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    quoteBox.textContent = quotes[randomIndex];
}, 4000);
